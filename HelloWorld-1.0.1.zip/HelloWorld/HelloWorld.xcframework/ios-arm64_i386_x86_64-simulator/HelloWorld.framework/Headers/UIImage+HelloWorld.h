//
//  UIImage+HelloWorld.h
//  ${POD_NAME
//
//  Created by irobbin1024 on 07/16/2021.
//

#import <UIKit/UIKit.h>

#define HelloWorldBundleName @"HelloWorld"

@interface UIImage (HelloWorld)

+ (UIImage *)HelloWorldImageNamed:(NSString *)imageName;


@end
